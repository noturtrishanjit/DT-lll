# DT lll website

This is a zero-dependency static site. From the project root, run:

```bash
python -m http.server 8000 --directory website
```

Then open `http://localhost:8000`. The playground is a clearly labeled browser-only simulation; it does not call the model checkpoint.
